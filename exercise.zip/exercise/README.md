# Jira Issue Analyst Rovo Agent using Forge

Support and engineering teams often face significant challenges when trying to understand issues in a queue. These challenges include identifying trending issues, recognizing patterns, and extracting actionable insights from a large volume of data. The sheer number of issues can make it difficult to prioritize effectively, leading to delays in addressing critical problems. Teams need efficient ways to gain insights and recommendations to improve response times and overall customer satisfaction.

This is a Forge app to build your own agent in Atlassian Rovo to address the above challenges.

# Prerequisites
Before we get started, make sure you have the following:

- A Jira Cloud instance where you can install and test your app

- Access to Atlassian Rovo. Currently, Forge Rovo modules are under Preview. To enrol, visit [Enable Rovo in your organization](https://admin.atlassian.com/rovo).

- Basic knowledge of JavaScript, React and [Forge platform](https://developer.atlassian.com/platform/forge/getting-started/).

- Completed [Build your first app](https://developer.atlassian.com/platform/forge/getting-started/).

- Knowledge of [Rovo Modules](https://developer.atlassian.com/platform/forge/manifest-reference/modules/rovo-index/)

# Demo
![Demo of Jira Issue Analyst Rovo app](./jira-analyst-rovo.gif)

## Getting Started


### 1. Login to Forge

```bash
forge login
```

This will prompt you to enter your atlassian id and API token. Navigate to [Atlassain Profile](https://id.atlassian.com/manage-profile/security/api-tokens) to create a token if you already don't have one.

### 2. Install the dependencies

```bash
npm install
```

### 3. Register the Forge app

This will create a Forge app and append the app ID to the `manifest.yml` file.

```bash
forge register
```

### 4. Deploy the Forge app

```bash
forge deploy 
```

### 5. Install the Forge app

```bash
forge install 
```

- Select 'Jira' as Atlassian product using the arrow keys and press the enter key.

- Enter the URL for your development site. For example, example.atlassian.net.

- Once the app is installed, you can go ahead in your Jira instance mentioned before and try out the app in your sample issue as shown in demo.

### 6. Debug the Forge app

Tunneling runs your app code locally on your machine via the Forge CLI, see [tunneling](https://developer.atlassian.com/platform/forge/tunneling/#tunneling) for more details.

```bash
forge tunnel
```


## Debugging

You can use the [`forge tunnel`](https://developer.atlassian.com/platform/forge/change-the-frontend-with-forge-ui/#set-up-tunneling) command to run your Forge app locally. 

### Notes

- Tutorial - [Build a Jira issue analyst Rovo Agent](https://developer.atlassian.com/platform/forge/build-a-jira-issue-analyst-rovo-agent/?utm_campaign=dx_dev_den&utm_source=cdac&utm_content=rovo_forge)

## Bonus

### Extend the Jira Issue Analyst Rovo Agent

In this exercise we will extend the capabilities of the rovo agent we built as part of exercise-1. We will specialise the agent to also "Approach an issue with a fresh perspective".

### Configure the agent with new capability

- Change the `prompt` in the `manifest.yml` file to incude the above new capability as:
```
You can perform the following jobs based on the user's request:

    a. Analyze the issues.

    b. Identify key themes and sentiments from the issues.

    c. Approach an issue with a fresh perspective

```

- Add instructions to achive above and update `prompt` in `manifest.yml` file as:
```
        ---
        c. Approach an issue with a fresh perspective.

        To do this, follow these steps:

        1. Check if the issue key is available in the context. If not, prompt the user to provide the issue key.

        2. Fetch the issue using the get-issue action.
           If the issue is not found, return a message to the user specifying the issue key used in this run.

        3. Analyze the issue data according to the user's request. Structure your response as follows:
          i.  A brief summary of the Issue".
          ii. Steps to resolve the issue.

        4. Return the analysis to the user.
```

- Add the converstaion starter "Approach an issue with a fresh perspective" under `conversationStarters` in the `manifest.yml` file

- Add the action `get-issue` under `actions` in the `manifest.yml` file

- Define the `get-issue` key under `action` in the `manifest.yml` file as:

```
  - key: get-issue
    name: Get Issue
    function: getIssueFunction
    description: Fetches a single issue from a project.
    inputs:
      issueKey:
        title: Issue Key
        type: string
        description: The issue key to fetch.
        required: true
    actionVerb: GET  

```

- Define the forge function corresponding to above action under `function` in manifest file as:

```
 - key: getIssueFunction
   handler: index.getIssue 
   
```

- Implement the `getIssue` function handler in the `src/index.js` file

Now redeploy the app using `forge deploy`. The agent should now be able to respond to queries around analysing a particular jira issue

## Support

See [Get help](https://developer.atlassian.com/platform/forge/get-help/) for how to get help and provide feedback.
If you require any additional help, please don't hesitate to reach out to our [developer community](https://community.developer.atlassian.com/).

## License

Copyright (c) 2024 Atlassian and others.
Apache 2.0 licensed, see [LICENSE](LICENSE) file.

[![From Atlassian](https://raw.githubusercontent.com/atlassian-internal/oss-assets/master/banner-cheers.png)](https://www.atlassian.com)
